import java.util.HashMap;

interface opInterface{
     HashMap<String, Operator> operators = new HashMap<String, Operator>();
      operators.put("+", new AdditionOperator() );
      operators.put("-", new SubstractionOperator() );
      operators.put("*", new MultiplicationOperator() );
      operators.put("/", new DivisionOperator() );
      operators.put("^", new PowerOperator() );
}

public abstract class Operator implements opInterface {


  // The Operator class should contain an instance of a HashMap
  // This map will use keys as the tokens we're interested in,
  // and values will be instances of the Operators.

  // Example:
  // Where does this declaration go? What should its access level be?
  // Class or instance variable? Is this the right declaration?
  // HashMap operators = new HashMap();
  // operators.put( "+", new AdditionOperator() );
  // operators.put( "-", new SubtractionOperator() );
private static String[] operatorList = {"+", "-", "*", "/", "^", "(", ")"};





  public abstract int priority();
  public abstract Operand execute( Operand op1, Operand op2 );
  public Operator( String token ) {

      //operators.get(token);
      //operators.put("(", new ParenthesisOperator() );
      //operators.put(")", new ParenthesisOperator() );

  }
  public Operator() {

  }

  public static Operator create( String token){
      return operators.get(token);
  }

  public static boolean check( String token ) {
    for(int i = 0; i < operatorList.length; i++){
       if(operatorList[i].equals(token)){
        return true;
       }
       else {
           return false;
       }
     }
return false;
  }


}
