

public class Operand {
  private String OpValue;

  public Operand( String token ) {
  OpValue = token;
  }

  public Operand( int value ) {
  OpValue = String.valueOf(value);
  }

  public int getValue() {
  return Integer.valueOf(OpValue);
  }

  public static boolean check( String token ) {
    try {
      @SuppressWarnings("unused")
      int x = Integer.parseInt( token );
      return true; //String is an Integer
    } catch (NumberFormatException e) {
      return false; //String is not an Integer
    }
  }
}
